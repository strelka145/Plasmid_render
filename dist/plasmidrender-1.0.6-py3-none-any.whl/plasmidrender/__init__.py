from .main import *
from .option import *
from .svg_draw import *

__copyright__    = 'Copyright (C) 2022 strelka'
__version__      = '1.0.6'
__license__      = 'MIT License'
__author__       = 'strelka'
__author_email__ = 'irohaprg@gmail.com'
__url__          = 'https://github.com/strelka145/Plasmid_render'
